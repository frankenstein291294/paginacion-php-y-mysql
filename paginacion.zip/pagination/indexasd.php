<?php

require './php/conexion.php';

$ruta = Conexion::ruta();

echo '<!DOCTYPE html>
      <html lang="en">

      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Pagination</title>
        <meta name="description" content="" />
        <meta name="keywords" content="" />

        <link rel="stylesheet" href="./public/css/style.css" />
        <link rel="stylesheet" href="./public/css/icomoon.css" />
      </head>

      <body>
        <header>
          <div class="container">
            <div class="logo">
              <p><a href=""><img src="./public/img/logo.png" alt="logo"><span>Portfolio</span></a></p>
            </div>
            <div class="search">
              <form action="">
                <i class="icon-search"></i>
                <input type="text" planceholder="search">
              </form>
            </div>
            <nav>
              <i class="icon-menu"></i>
            </nav>
          </div>
        </header>';

        $ruta1 = null;

        if (isset($_GET['ruta'])) {

          $ruta1 = $_GET['ruta'];

        }

        echo $ruta1;


        $table = 'portfolio';
        $mode = 'DESC';

        if ($ruta1 != null) {

          $init = ($ruta1 - 1) * 6;
          $max = 6;

        } else {

          $ruta1 = 1;
          $init = 0;
          $max = 6;

        }


        echo '<section class="portfolio">
          <div class="container">
            <div class="row">';

              $statement = Conexion::conectar()->prepare("SELECT * FROM $table ORDER BY id $mode LIMIT $init, $max");
              $statement->execute();

              $portfolio = $statement->fetchAll();

              if (is_array($portfolio) || is_object($portfolio)) {

                for ($i = 0; $i < count($portfolio); $i ++) {

                  echo '<div class="col">
                          <div class="container-portfolio">
                            <a href=""><img src="./public/img/portfolio/'.$portfolio[$i]['img'].'" alt=""></a>
                            <h2><small><a href="">'.$portfolio[$i]['title'].'</a></small></h2>
                            <div class="button">
                              <a href="" class="details">Detalles</a>
                            </div>
                          </div>
                        </div>';

                }

              } else {

                echo '<p>Aun no hay proyectos</p>';

              }

              echo '

            </div>
          </div>
        </section>';

        if (is_array($portfolio) || is_object($portfolio)) {

          echo '<section class="pagination">
            <center>
              <ul>';

                $statement1 = Conexion::conectar()->prepare("SELECT * FROM $table");
                $statement1->execute();

                $cantPortfolio = $statement1->fetchAll();

                $pages = ceil(count($cantPortfolio) / 6);

                if ($ruta1 == 1) echo '<li><a class="no-link" href="'.$ruta.'?ruta='.($ruta1 - 1).'"><i class="icon-circle-left"></i></a></li>';

                else echo '<li><a href="'.$ruta.'?ruta='.($ruta1 - 1).'"><i class="icon-circle-left"></i></a></li>';
                

                for ($i = 1; $i <= $pages; $i ++) {

                  if ($ruta1 == $i) echo '<li><a class="active" href="'.$ruta.'?ruta='.$i.'">'.$i.'</a></li>';

                  else echo '<li><a href="'.$ruta.'?ruta='.$i.'">'.$i.'</a></li>';

                }

                if ($ruta1 == $pages)echo '<li><a class="no-link" href="'.$ruta.'?ruta='.($ruta1 + 1).'"><i class="icon-circle-right"></i></a></li>';

                else echo '<li><a href="'.$ruta.'?ruta='.($ruta1 + 1).'"><i class="icon-circle-right"></i></a></li>';
                



              echo '</ul>
            </center>
          </section>';

        }


        echo '<script src="./public/js/script.js"></script>

      </body>

      </html>';


